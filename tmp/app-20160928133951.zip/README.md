# ZCC

The ZCC App adds BCC functionality into Zendesk ticketing.  First an Admin must create a list of BCC-able email addresses and then agents can choose from that list while working in tickets.

Please submit bug reports to [ZCC](https://github.com/zendesklabs/zcc). Pull requests are welcome.

### Screenshot(s):
![My image](http://url/to/image/png)
![My image](http://url/to/image/png)
