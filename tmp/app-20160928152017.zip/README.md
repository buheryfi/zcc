# ZCC

The ZCC App adds BCC functionality into Zendesk ticketing.  First an Admin must create a list of BCC-able email addresses and then agents can choose from that list while working in tickets.

Please submit bug reports to [ZCC](https://github.com/zendesklabs/zcc). Pull requests are welcome.

### Screenshot(s):
![](https://github.com/buheryfi/zcc/blob/master/assets/screenshot-0.png)
![](https://github.com/buheryfi/zcc/blob/master/assets/screenshot-1.png)
![](https://github.com/buheryfi/zcc/blob/master/assets/screenshot-2.png)
